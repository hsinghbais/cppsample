﻿using System;
using System.Runtime.InteropServices;

namespace ConsoleAppCSharp
{
    class Program
    {
        //[DllImport("./lib/Operations.dll")]
        //public static extern IntPtr Create(int a, int b);

        //[DllImport("./lib/Operations.dll")]
        //public static extern int AttemptAdd(IntPtr obj);


        static void Main(string[] args)
        {

          
            int result=  WrapperClass.Wrapper.AddOperation(4, 5);

            Console.WriteLine($"Result Value = {result}");
            Console.ReadLine();
        }
    }
}
