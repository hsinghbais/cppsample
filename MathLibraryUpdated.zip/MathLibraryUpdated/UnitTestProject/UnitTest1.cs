using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int result = WrapperClass.Wrapper.AddOperation(4, 5);
            Assert.AreEqual(result, 9);
        }
    }
}
