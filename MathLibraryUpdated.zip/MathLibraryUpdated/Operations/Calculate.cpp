#include "Calculate.h"
#include "pch.h"


namespace operations {

operation::operation(int x) {
	this->x = x;
	this->y = 0;
}
operation::operation(int x,int y) {
	this->x = x;
	this->y = y;
}
int operation::Sum2()
{
	return this->x + this->y;
}

	int operation::Sum(int a, int b)
	{
		return a + b;
	}

	int operation::Subtract(int a, int b)
	{
		return a - b;
	}

	int operation::Multiply(int a, int b)
	{
		return a * b;
	}
}
