#pragma once

namespace operations {
	
	  class operation {
		  int x, y;
	public:
		//operation( );
		operation(int x);
		operation(int x, int y);
		static __declspec(dllexport) int Sum(int a, int b);
		static __declspec(dllexport) int Subtract(int a, int b);
		static __declspec(dllexport) int Multiply(int a, int b);

		//for C# project
		 int Sum2();
		/* int Subtract2();
		 int Multiply2();*/

	  };

	  extern "C" __declspec(dllexport) void* Create(int a, int b) {
		  return (void*) new operation(a, b);
	  }
	  extern "C" __declspec(dllexport) int AttemptAdd(operation * obj) {
		  return obj->Sum2();
	  }
}
