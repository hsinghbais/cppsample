﻿using System;
using System.Runtime.InteropServices;

namespace WrapperClass
{
    public class Wrapper
    {
        [DllImport("./lib/Operations.dll")]
        public static extern IntPtr Create(int a, int b);

        [DllImport("./lib/Operations.dll")]
        public static extern int AttemptAdd(IntPtr obj);


        public static int AddOperation(int a,int b)
        {
            return a + b;
        }
    }
}
